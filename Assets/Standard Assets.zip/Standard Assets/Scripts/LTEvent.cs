public class LTEvent
{
	public int id;

	public object data;

	public LTEvent(int id, object data)
	{
		this.id = id;
		this.data = data;
	}
}
