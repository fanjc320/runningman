internal class BitString
{
	public int len;

	public int val;
}
