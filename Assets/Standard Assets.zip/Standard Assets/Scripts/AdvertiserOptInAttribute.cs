using UnityEngine;

public class AdvertiserOptInAttribute : PropertyAttribute
{
}
