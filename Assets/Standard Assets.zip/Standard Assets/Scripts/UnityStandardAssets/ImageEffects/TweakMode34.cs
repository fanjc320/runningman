namespace UnityStandardAssets.ImageEffects
{
	public enum TweakMode34
	{
		Basic,
		Complex
	}
}
