namespace UnityStandardAssets.ImageEffects
{
	public enum BloomScreenBlendMode
	{
		Screen,
		Add
	}
}
