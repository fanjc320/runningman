namespace UnityStandardAssets.ImageEffects
{
	public enum HDRBloomMode
	{
		Auto,
		On,
		Off
	}
}
