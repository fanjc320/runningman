namespace UnityStandardAssets.ImageEffects
{
	public enum LensflareStyle34
	{
		Ghosting,
		Anamorphic,
		Combined
	}
}
